#!/bin/sh

tar -zcf /tmp/tactical-r-server.tar.gz --exclude=./optimization-integration-test --exclude=./.idea --exclude=./.git --exclude=./.Rproj.user --exclude=./rserver.Rproj --exclude=nohup.out --exclude=.DS_Store .
cp /tmp/tactical-r-server.tar.gz .
