#!/bin/sh -e

R -f Install.R

sh ./utils/set-up-git-hooks.sh