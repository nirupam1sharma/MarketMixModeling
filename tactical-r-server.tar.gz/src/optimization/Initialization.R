SourceMarket           <- "MarketId"
SourceInstrument      <- "InstrumentId"
SourceActivity          <- "Activity"
DestinationMarket      <- "ReceivingMarketId"
NetProfitFormulaString <- "NetProfitFormula"

MarketInstrument      <- c(SourceMarket, SourceInstrument)
DestinationBased      <- c(DestinationMarket)
